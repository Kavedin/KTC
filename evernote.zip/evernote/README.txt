Portfolio Plugin for Evernote

Save the folder under the portfolio folder in moodle.
You'll need an Evernote Developer API key to activate it.
Go through the link http://docs.moodle.org/25/en/admin/portfolio/evernote for complete instructions and documentation.